const fs = require('fs'),
   FormData = require('form-data'),
   axios = require('axios')
   
module.exports = Scrape => {


}