const fs = require('fs');

// You can add baileys messaging functionality here . . .
module.exports = clips => {
    
}
