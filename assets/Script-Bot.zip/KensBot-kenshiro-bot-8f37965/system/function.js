const moment = require('moment-timezone')
moment.tz.setDefault('Asia/Jakarta')
const fs = require('fs')

module.exports = Func => {
     
}